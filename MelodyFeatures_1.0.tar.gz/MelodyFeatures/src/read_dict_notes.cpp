
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <Rcpp.h> 

using namespace Rcpp;
using namespace std ;
//' Reads the file "dictionaries/dict_and_equiv.csv" of note names corresponding to the numbers in the midifile. This is needed to identify the tonic note. Both sharp and flat notation can be read.
// [[Rcpp::export]]

std::vector < std::vector < std::string > > read_dict_notes(std::string dictn){

  
  std::cout<<" read_dict dictname: "<<dictn<<endl;
  std::ifstream t;
  t.open(dictn);
  
  if (t.is_open()) {std::cout<<" read dict stream open "<<endl;}
  std::vector < std::vector < std::string > > notes_dict;
  for (std::string line, word; std::getline(t, line);)
  {		
    std::vector < std::string > temp;
    std::istringstream iss(line);
    while (std::getline(iss, word, ' '))
    {
      temp.push_back( word ); 
    }
    notes_dict.push_back(temp);
  }		
  t.close();
  
  return(notes_dict);
}
