#include <vector>

#include <fstream>
#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ;


//' Counts the number of occurrence of 3-grams, normalized by the total number of intervals in the midi file (=number of notes -2).
//' samp: object of type samp (read from readmidicsv.R)
//[[Rcpp::export]]

std::vector <double> occurrence_3grams(std::vector < std::vector < int > >& samp) { // statstics how often every interval appears
//std::vector <std::vector <double> > occurrence_3grams(std::vector < std::vector < int > >& samp) { // statstics how often every interval appears


// calculate interval std::vector

	std::vector <int> intervals1;
	for(int i=0;i<samp.size()-1;i++)
	{
	intervals1.push_back(samp[i+1][1]-samp[i][1]);
	}

// calculate triple interval matrix -12 to +12
std::vector <std::vector <int> > intervals_triple;


for(int i=0; i< 25; i++)
{
for(int j=0; j< 25; j++)
{
	intervals_triple.push_back(std::vector <int> ());
	intervals_triple[intervals_triple.size()-1].push_back(i-12);
	intervals_triple[intervals_triple.size()-1].push_back(j-12);
	intervals_triple[intervals_triple.size()-1].push_back(0);
}
}


// see where intervals fit


for(int i=0;i<intervals1.size()-1;i++)
	{
	for(int j=0;j<intervals_triple.size();j++)
	{
	if((intervals1[i]==intervals_triple[j][0])and(intervals1[i+1]==intervals_triple[j][1]))
		{
			intervals_triple[j][2]++;
		}
	}
	}


std::vector <double>  occ_tripleint;

std::vector <std::vector <double> > occ_triple_int;
for(int i=0; i<intervals_triple.size();i++)
	{

double newn=(1000*intervals_triple[i][0]+intervals_triple[i][1]);
int is;
occ_triple_int.push_back(std::vector <double> ());
occ_triple_int[occ_triple_int.size()-1].push_back(newn);

if(intervals1.size()<2){is=1;}else{is=(intervals1.size()-1);}
occ_triple_int[occ_triple_int.size()-1].push_back(double(intervals_triple[i][2])/double(is));

occ_tripleint.push_back(double(intervals_triple[i][2])/double(is));
	}

//return occ_triple_int;

return occ_tripleint;
}

