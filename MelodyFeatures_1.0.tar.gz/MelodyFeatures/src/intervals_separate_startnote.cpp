

#include <algorithm>
#include <vector>

#include <fstream>
#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ;




//'Calculates the occurrence of each interval (measured in half tones), normalized by the total number of intervals in the midi (=number of notes -1). Intervals are counted separately depending on which note in the scale they start in (with respect to the tonic)
//[[Rcpp::export]]
std::vector <double> intervals_separate_startnote(std::vector < std::vector < int > >& samp, int tonic) {
//std::vector < std::vector <double> > occurrence_intervals_startnote(std::vector < std::vector < int > >& samp, int tonic) {


/*


std::vector <int> different_notes; //1st column: note, second:


std::vector < std::vector <int > > hist_notes;

different_notes.push_back(samp[0][1]);

for(int i=0;i<samp.size();i++)
{
int k=0;
for(int j=0;j<different_notes.size();j++)
	{
	if(samp[i][1]==different_notes[j]){
	k=1;
	}
	}
if(k==0){different_notes.push_back(samp[i][1]);}
}


std::sort(different_notes.begin(), different_notes.end());           


for(int j=0;j<different_notes.size();j++){
hist_notes.push_back(std::vector <int>());

hist_notes[j].push_back(different_notes[j]); // how many notes
hist_notes[j].push_back(0); // how many notes
hist_notes[j].push_back(0); // cumulative length of these notes
}


for(int i=0;i<samp.size();i++)
{
	for(int j=0;j<different_notes.size();j++)
	{
		if(samp[i][1]==different_notes[j]){
		hist_notes[j][1]++;
		hist_notes[j][2]=hist_notes[j][2]+samp[i][0];
		}
	}
}



for(int i=0;i<hist_notes.size();i++)
	{
	hist_notes[i][0]=((hist_notes[i][0]+36)% 12);
	}
std::sort(hist_notes.begin(),hist_notes.end());


*/

std::vector < std::vector <int> > intervals_startval;
for(int i=0;i<37;i++)
{
for(int j=0;j<24;j++)
	{

	intervals_startval.push_back(std::vector<int>());
	intervals_startval[intervals_startval.size()-1].push_back(i-12);//start value
	intervals_startval[intervals_startval.size()-1].push_back(j-12);//interval
	intervals_startval[intervals_startval.size()-1].push_back(0);//occurrence
	intervals_startval[intervals_startval.size()-1].push_back(0);//note length on that
	}
}

int nbnotes=0;
double normlength=0;
for(int i=0;i<samp.size()-1;i++)
{
	for(int k=0;k<intervals_startval.size();k++)
	{
	if(((samp[i][1]-tonic)==intervals_startval[k][0])and((samp[i+1][1]-samp[i][1])==intervals_startval[k][1]))
	{
	intervals_startval[k][2]++;
	intervals_startval[k][3]=intervals_startval[k][3]+(samp[i+1][2]-samp[i][2]);
	normlength=(normlength+double(samp[i+1][2]-samp[i][2]));
	nbnotes++;
	}
	}
}

std::vector <std::vector < double > > int_startval_occ;


std::vector < double >  int_startvalocc;

for(int i=0;i<intervals_startval.size();i++)
	{

	int_startval_occ.push_back(std::vector <double>());
	int_startval_occ[int_startval_occ.size()-1].push_back(double(intervals_startval[i][0]));

	int_startval_occ[int_startval_occ.size()-1].push_back(double((i)%24)-12);
	int_startval_occ[int_startval_occ.size()-1].push_back(double(intervals_startval[i][2])/double(nbnotes));

	int_startvalocc.push_back(double(intervals_startval[i][2])/double(nbnotes));
	}


/*
std::ofstream ou;
ou.open("int_startval_occ.csv");
for(int i=0;i<int_startval_occ.size();i++)
{	
	//cout<<int_startval_occ[i][0]<<"_"<<int_startval_occ[i][1]<<" * "<<int_startval_occ[i][2]<<endl; 
	ou<<int_startval_occ[i][0]<<"_"<<int_startval_occ[i][1]<<" "<<int_startval_occ[i][2]<<endl; // to generate names
	
	//cout<<int_startval_occ[i][0]<<" * "<<int_startval_occ[i][1]<<endl; // to generate names
	//ou<<int_startval_occ[i][0]<<" "<<int_startval_occ[i][1]<<endl; // to generate names
}
ou.close();
*/

//return int_startval_occ;

return int_startvalocc;
}

