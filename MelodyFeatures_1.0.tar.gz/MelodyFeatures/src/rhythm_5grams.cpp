#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <math.h>
#include <Rcpp.h> 
#include <algorithm> 


using namespace Rcpp;

using namespace std ;



//' Calculates rhythm 5-grams. The notation is multiples  (up to 6 times)  of the shortest notelength. The features are normalized by the total number of rhythm 5-grams in the midi melody (= number of notes minus 4)
//[[Rcpp::export]]


std::vector <double>  rhythm_5grams(std::vector< std::vector < int > >& samp, std::vector< std::vector < std::string > >& rhythm_all_string) {
//std::vector <std::vector <double> > rhythm_5grams(std::vector< std::vector < int > >& samp, std::vector< std::vector < std::string > >& rhythm_all_string) {
std::vector <std::vector <int> >int_final;
std::vector <int> times1;

for(int i=0;i<samp.size()-1;i++)
{
times1.push_back(samp[i+1][2]-samp[i][2]);
}

times1.push_back(samp[samp.size()-1][0]);//length of the last note

std::vector <int> t_ordered;
for(int i=0;i<times1.size();i++)
{
t_ordered.push_back(times1[i]);
}

sort(t_ordered.begin(), t_ordered.end());


std::vector < std::vector <int> > hist_filled;

int max1=t_ordered[t_ordered.size()-1];

std::vector <std::vector <int> > hist;
for(int i=0;i<max1+1;i++)
	{
	hist.push_back(std::vector <int>());
	hist[hist.size()-1].push_back(i);
	hist[hist.size()-1].push_back(0);
	}


for(int i=0;i<hist.size();i++)
{
for(int j=0;j<t_ordered.size();j++)
{
if(hist[i][0]==t_ordered[j]){
hist[i][1]++;
			}

}
if(hist[i][1]!=0){

 hist_filled.push_back(std::vector <int>());
hist_filled[hist_filled.size()-1].push_back(hist[i][0]);
hist_filled[hist_filled.size()-1].push_back(hist[i][1]);

}
}

/////////////////////////////////////////////////////////////////////////

for(int i=1;i<hist_filled.size();i++)
{
if((hist_filled[i][0]==hist_filled[i-1][0]+1)or(hist_filled[i][0]==hist_filled[i-1][0]+2))
{
	if(hist_filled[i][1]>hist_filled[i-1][1]){hist_filled[i][1]=hist_filled[i][1]+hist_filled[i-1][1]; // shuffle them to bigger
						hist_filled[i-1][1]=0;
						}

	if(hist_filled[i][1]<hist_filled[i-1][1]){hist_filled[i-1][1]=hist_filled[i-1][1]+hist_filled[i][1]; // shuffle them to bigger
						hist_filled[i][1]=0;
						}

}

}



for(int i=hist_filled.size()-1; i>=0 ;i--)
{
if(hist_filled[i][1]==0){hist_filled[i].erase(hist_filled[i].begin(),hist_filled[i].end());
hist_filled.erase(hist_filled.begin()+i);
}
}
////////////////////////////////////////////////////////////////////////////////////
// correct of not multiple of shortest:

for(int i=0;i<hist_filled.size();i++)
{

for(int j=1;j<15;j++)
{
int hmult=0.5*j*hist_filled[0][0];

if((hist_filled[i][0]== hmult+2)or(hist_filled[i][0]== hmult+2)or(hist_filled[i][0]== hmult-1)or(hist_filled[i][0]== hmult-2))
{hist_filled[i][0]=hmult;}

}

}

//////////////////////////////////////////////////////////////////////////////////////
std::vector <double> hdiv;

for(int i=0;i<hist_filled.size(); i++)
{
hdiv.push_back(double(hist_filled[i][0])/double(hist_filled[0][0]));
hist_filled[i].push_back(i+1);
}



for(int i=0;i<hdiv.size();i++)
{
hdiv[i]=(0.01*round(hdiv[i]*100));

int div=int(100*(hdiv[i]-floor(hdiv[i])));
if(div==34){hdiv[i]=hdiv[i]-0.01;} // comparison only works with integer
if(div==35){hdiv[i]=hdiv[i]-0.02;}
if(div==32){hdiv[i]=hdiv[i]+0.01;}
if(div==31){hdiv[i]=hdiv[i]+0.02;}
if(div==68){hdiv[i]=hdiv[i]-0.01;}
if(div==69){hdiv[i]=hdiv[i]-0.02;}
if(div==66){hdiv[i]=hdiv[i]+0.01;}
if(div==65){hdiv[i]=hdiv[i]+0.02;}


}



std::vector <double> patall;

int sum_patall=0;

for(int i=0;i<times1.size();i++)
{
for(int j=0;j<hist_filled.size();j++)
{
if((times1[i]==hist_filled[j][0])or(times1[i]==hist_filled[j][0]+1)or(times1[i]==hist_filled[j][0]-1)or(times1[i]==hist_filled[j][0]-2)or(times1[i]==hist_filled[j][0]+2)or(times1[i]==hist_filled[j][0]-3)or(times1[i]==hist_filled[j][0]+3))
	{

	patall.push_back(hdiv[j]); 
	}
}
sum_patall=sum_patall+int(patall[i]);
}





std::vector <int> testfn;
std::vector <int> notmult;
std::vector <int> ttake;
int trynextmult=1;
int tt=1;
int k=2;
while(trynextmult==1){
trynextmult=0;
for (int i=0;i<patall.size();i++)
{
tt=1;
double conda = std::floor(patall[i]*k * 100.0) / 100.0;
double condb = std::floor(((patall[i]*k)+0.01) * 100.0) / 100.0;
double condc = std::floor(((patall[i]*k)-0.01) * 100.0) / 100.0;
double condd = std::floor(((patall[i]*k)+0.02) * 100.0) / 100.0;
double conde = std::floor(((patall[i]*k)-0.02) * 100.0) / 100.0;


//std::cout<<i<<" "<<patall[i]<<" || a: "<<conda<<" b: "<<condb<<" c: "<<condc<<" d: "<<condd<<" e: "<<conde<<" || "<<endl; 
if((double(conda)==double((std::ceil(conda))))or(double(conda)==double((std::floor(conda))))){ttake.push_back(conda);tt=0;
//std::cout<<i<<" || a: "<<conda<<" "<<(std::ceil(conda))<<" "<<(std::floor(conda))<<endl;
}
if((double(condb)==double((std::ceil(condb))))or(double(condb*100)==double((std::floor(condb)*100)))){ttake.push_back(int(condb));tt=0;
//std::cout<<i<<" || b: "<<condb<<" "<<(std::ceil(condb))<<" "<<(std::floor(condb))<<endl;
}
if((double(condc)==double((std::ceil(condc))))or(double(condc)==double((std::floor(condc))))){ttake.push_back(int(condc));tt=0;
//std::cout<<i<<" || c: "<<condc<<" "<<(std::ceil(condc))<<" "<<(std::floor(condc))<<endl;
}
if((double(condd)==double((std::ceil(condd))))or(double(condd)==double((std::floor(condd))))){ttake.push_back(int(condd));tt=0;
//std::cout<<i<<" || d: "<<condd<<" "<<(std::ceil(condd))<<" "<<(std::floor(condd))<<endl;
}
if((double(conde)==double((std::ceil(conde))))or(double(conde)==double((std::floor(conde))))){ttake.push_back(int(conde));tt=0;
//std::cout<<i<<" || e: "<<conde<<" "<<(std::ceil(conde))<<" "<<(std::floor(conde))<<endl;
}
	if(tt==1){
	trynextmult=1;
//std::cout<<" another factor necessary "<<k<<endl;
	}

}

k++;

} //while trynextmult==1

k=k-1;
//std::cout<<"factor needed for multiplication: "<<k<<endl;
int multfactor=k;
////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////

// correct fraction of hdiv;

/////////////////////////////////////////////////////////////////////

// now: which tuples of length 4 occur how often

std::vector <std::vector <int > > fivetuples;
//fivetuples.push_back(std::vector <int>());
for(int i=0;i<ttake.size()-4;i++)
{
	
	//std::cout<<"ttake || "<<ttake[i]<<" "<<ttake[i+1]<<" "<<ttake[i+2]<<" "<<ttake[i+3]<<" "<<ttake[i+4]<<endl; 

	int m1= 1;//gcd(ttake[i],ttake[i+1]);
	int min_=ttake[i];
	if(ttake[i+1]<min_){min_=ttake[i+1];}
	for(int k=1;k<=min_;k++){
	if((ttake[i]%k==0)and(ttake[i+1]%k==0)){
		m1=k;
		}
	}


	int m2= 1;//gcd(ttake[i+2],ttake[i+3]);
	min_=ttake[i+2];
	if(ttake[i+3]<min_){min_=ttake[i+3];}
	for(int k=1;k<=min_;k++){
	if((ttake[i+2]%k==0)and(ttake[i+3]%k==0)){
		m2=k;
		}
	}


	int m12= 1;//gcd)m1,m2);
	min_=m1;
	if(m2<min_){min_=m2;}
	for(int k=1;k<=min_;k++){
	if((m1%k==0)and(m2%k==0)){
		m12=k;
		}
	}

	int m123= 1;//gcd)m1,m2);
	min_=m12;
	if(ttake[i+4]<min_){min_=ttake[i+4];}
	for(int k=1;k<=min_;k++){
	if((m12%k==0)and(ttake[i+4]%k==0)){
		m123=k;
		}
	}


	//std::cout<<"gcd2: "<<m123<<endl; 

 	fivetuples.push_back(std::vector <int>());
	fivetuples[fivetuples.size()-1].push_back(ttake[i]/m123);
	fivetuples[fivetuples.size()-1].push_back(ttake[i+1]/m123);
	fivetuples[fivetuples.size()-1].push_back(ttake[i+2]/m123);
	fivetuples[fivetuples.size()-1].push_back(ttake[i+3]/m123);
	fivetuples[fivetuples.size()-1].push_back(ttake[i+4]/m123);
	fivetuples[fivetuples.size()-1].push_back(0);

	fivetuples[fivetuples.size()-1].push_back(int(ttake[i+0]+ttake[i+1]+ttake[i+2]+ttake[i+3]+ttake[i+4]));


//std::cout<<"fivetuples || "<<fivetuples[fivetuples.size()-1][0]<<" "<<fivetuples[fivetuples.size()-1][1]<<" "<<fivetuples[fivetuples.size()-1][2]<<" "<<fivetuples[fivetuples.size()-1][3]<<" "<<fivetuples[fivetuples.size()-1][3]<<endl<<endl;
	
}


std::vector <std::vector <int> > bin2;
int lb2= ceil(double(hist.size())/2);


//////////////////////////////////////////////////////////////////////////


std::vector <std::vector <int> > rhythm_all_four;
std::vector <std::vector <double> > rhythm_features;

for(int i=0;i<rhythm_all_string.size();i++)
{
	rhythm_all_four.push_back(std::vector <int>());

	rhythm_features.push_back(std::vector <double>());
	rhythm_features[i].push_back(i); // this will become std::vector to return
	rhythm_features[i].push_back(0); 

	for(int j=0;j<rhythm_all_string[i].size();j++)
	{
	rhythm_all_four[i].push_back(std::stoi(rhythm_all_string[i][j]));

	//std::cout<<rhythm_all_four[rhythm_all_four.size()-1][j]<<" r ";
	}
	//std::cout<<endl;
}

/*
for(int j=0;j<2;j++)
{
	std::cout<<"rhythm_all_four[j]: "<<rhythm_all_four[j][0]<<" . "<<rhythm_all_four[j][1]<<" ."<<rhythm_all_four[j][2]<<" . "<<rhythm_all_four[j][3]<<" . "<<rhythm_all_four[j][4]<<endl;
}
*/
////////////////////////////////////////////////////////////////////////////




int sum_tuples_found=0;

for(int i=0;i<fivetuples.size();i++)
{  //std::cout<<" * "<<i<<" ";


//std::cout<<"fivetuples[i]: "<<fivetuples[i].size()<<endl;
//std::cout<<"fivetuples[i]: "<<fivetuples[i][0]<<" x "<<fivetuples[i][1]<<" x "<<fivetuples[i][2]<<" x "<<fivetuples[i][3]<<" x "<<fivetuples[i][4]<<endl;

for(int j=0;j<rhythm_all_four.size();j++)
	{

//	std::cout<<"rhythm_all_four[j]: "<<rhythm_all_four[j][0]<<" . "<<rhythm_all_four[j][1]<<" ."<<rhythm_all_four[j][2]<<" . "<<rhythm_all_four[j][3]<<" . "<<rhythm_all_four[j][4]<<endl;
//std::cout<<"fivetuples[i]: "<<fivetuples[i][0]<<" "<<fivetuples[i][1]<<" "<<fivetuples[i][2]<<" "<<fivetuples[i][3]<<" "<<fivetuples[i][4]<<endl<<endl;

	if((fivetuples[i][0]==rhythm_all_four[j][0])and(fivetuples[i][1]==rhythm_all_four[j][1])and(fivetuples[i][2]==rhythm_all_four[j][2])and(fivetuples[i][3]==rhythm_all_four[j][3])and(fivetuples[i][4]==rhythm_all_four[j][4])){
	//std::cout<<" tuple found "<<i<<endl;
	rhythm_features[j][1]=rhythm_features[j][1]+1; 
	sum_tuples_found=sum_tuples_found+1;

	}


	}

//std::cout<<endl<<endl;
}



std::vector <double> rhythmfeatures;

double fraction_found=(double(sum_tuples_found)/double(fivetuples.size()));

for(int j=0;j<rhythm_features.size();j++)
	{

	rhythm_features[j][1]=(rhythm_features[j][1]/double(fivetuples.size()));
	rhythmfeatures.push_back(rhythm_features[j][1]);
	}

rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(fraction_found);

rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(fivetuples.size());


rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(fivetuples.size());
/////////////////////////////////////////////////////////////////////////////

//return rhythm_features;


//std::vector <double> rhythmfeatures;
//rhythmfeatures.push_back(1);

return rhythmfeatures;

}

