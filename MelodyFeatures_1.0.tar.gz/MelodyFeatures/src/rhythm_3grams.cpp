#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <math.h>
#include <Rcpp.h> 
#include <functional>
#include <algorithm> 




using namespace Rcpp;
using namespace std ;

//' Calculates rhythm 3-grams. The notation is multiples (up to 6 times) of the shortest notelength. The features are normalized by the total number of rhythm 3-grams in the midi melody (= number of notes minus two)

//[[Rcpp::export]]


std::vector <double>  rhythm_3grams(std::vector< std::vector < int > >& samp, std::vector< std::vector < std::string > >& rhythm_all_string) {
//std::vector <std::vector <double> > rhythm_3grams(std::vector< std::vector < int > >& samp, std::vector< std::vector < std::string > >& rhythm_all_string) {


std::vector <std::vector <int> >int_final;
std::vector <int> times1;

for(int i=0;i<samp.size()-1;i++)
{
times1.push_back(samp[i+1][2]-samp[i][2]);
}

times1.push_back(samp[samp.size()-1][0]);//length of the last note


std::vector <int> t_ordered;
for(int i=0;i<times1.size();i++)
{
t_ordered.push_back(times1[i]);
}

sort(t_ordered.begin(), t_ordered.end());



std::vector < std::vector <int> > hist_filled;

int max1=t_ordered[t_ordered.size()-1];

std::vector <std::vector <int> > hist;
for(int i=0;i<max1+1;i++)
	{
	hist.push_back(std::vector <int>());
	hist[hist.size()-1].push_back(i);
	hist[hist.size()-1].push_back(0);
	}

for(int i=0;i<hist.size();i++)
{
for(int j=0;j<t_ordered.size();j++)
{
if(hist[i][0]==t_ordered[j]){
hist[i][1]++;
			}

}
if(hist[i][1]!=0){

 hist_filled.push_back(std::vector <int>());
hist_filled[hist_filled.size()-1].push_back(hist[i][0]);
hist_filled[hist_filled.size()-1].push_back(hist[i][1]);

}
}



/////////////////////////////////////////////////////////////////////////

for(int i=1;i<hist_filled.size();i++)
{
if((hist_filled[i][0]==hist_filled[i-1][0]+1)or(hist_filled[i][0]==hist_filled[i-1][0]+2))
	{
	if(hist_filled[i][1]>hist_filled[i-1][1]){hist_filled[i][1]=hist_filled[i][1]+hist_filled[i-1][1]; // shuffle them to bigger
						hist_filled[i-1][1]=0;
						}

	if(hist_filled[i][1]<hist_filled[i-1][1]){hist_filled[i-1][1]=hist_filled[i-1][1]+hist_filled[i][1]; // shuffle them to bigger
						hist_filled[i][1]=0;
						}

	}
}



for(int i=hist_filled.size()-1; i>=0 ;i--)
{
	if(hist_filled[i][1]==0)
	{
	hist_filled[i].erase(hist_filled[i].begin(),hist_filled[i].end());	
	hist_filled.erase(hist_filled.begin()+i);
	}
}
////////////////////////////////////////////////////////////////////////////////////
// correct of not multiple of shortest:

for(int i=0;i<hist_filled.size();i++)
{
	for(int j=1;j<15;j++)
	{	
	int hmult=0.5*j*hist_filled[0][0];
		if((hist_filled[i][0]== hmult+2)or(hist_filled[i][0]== hmult+2)or(hist_filled[i][0]== hmult-1)or(hist_filled[i][0]== hmult-2))
		{hist_filled[i][0]=hmult;}
	}
}


//////////////////////////////////////////////////////////////////////////////////////
std::vector <double> hdiv;

for(int i=0;i<hist_filled.size(); i++)
{
hdiv.push_back(double(hist_filled[i][0])/double(hist_filled[0][0]));
hist_filled[i].push_back(i+1);
}



for(int i=0;i<hdiv.size();i++)
{
hdiv[i]=(0.01*round(hdiv[i]*100));

int div=int(100*(hdiv[i]-std::floor(hdiv[i])));
if(div==34){hdiv[i]=hdiv[i]-0.01;} // comparison only works with integer
if(div==35){hdiv[i]=hdiv[i]-0.02;}
if(div==32){hdiv[i]=hdiv[i]+0.01;}
if(div==31){hdiv[i]=hdiv[i]+0.02;}
if(div==68){hdiv[i]=hdiv[i]-0.01;}
if(div==69){hdiv[i]=hdiv[i]-0.02;}
if(div==66){hdiv[i]=hdiv[i]+0.01;}
if(div==65){hdiv[i]=hdiv[i]+0.02;}
//std::cout<<hdiv[i]<<" ";
}

//std::cout<<endl;

std::vector <double> patall;

int sum_patall=0;

for(int i=0;i<times1.size();i++)
{
for(int j=0;j<hist_filled.size();j++)
{
if((times1[i]==hist_filled[j][0])or(times1[i]==hist_filled[j][0]+1)or(times1[i]==hist_filled[j][0]-1)or(times1[i]==hist_filled[j][0]-2)or(times1[i]==hist_filled[j][0]+2)or(times1[i]==hist_filled[j][0]+3)or(times1[i]==hist_filled[j][0]-3))
	{patall.push_back(hdiv[j]);
//std::cout<<"patall last "<<patall[patall.size()-1]<<endl;
 }
}
sum_patall=sum_patall+int(patall[i]);
}

//////////////////////////////////////
// now test: by which number multipled are patall all integers


std::vector <int> testfn;
std::vector <int> notmult;
std::vector <int> ttake;
int trynextmult=1;
int tt=1;
int k=2;
while(trynextmult==1){
trynextmult=0;
for (int i=0;i<patall.size();i++)
{
tt=1;
double conda = std::floor(patall[i]*k * 100.0) / 100.0;
double condb = std::floor(((patall[i]*k)+0.01) * 100.0) / 100.0;
double condc = std::floor(((patall[i]*k)-0.01) * 100.0) / 100.0;
double condd = std::floor(((patall[i]*k)+0.02) * 100.0) / 100.0;
double conde = std::floor(((patall[i]*k)-0.02) * 100.0) / 100.0;


if((double(conda)==double((std::ceil(conda))))or(double(conda)==double((std::floor(conda))))){ttake.push_back(conda);tt=0;
}
if((double(condb)==double((std::ceil(condb))))or(double(condb*100)==double((std::floor(condb)*100)))){ttake.push_back(int(condb));tt=0;
}
if((double(condc)==double((std::ceil(condc))))or(double(condc)==double((std::floor(condc))))){ttake.push_back(int(condc));tt=0;
}
if((double(condd)==double((std::ceil(condd))))or(double(condd)==double((std::floor(condd))))){ttake.push_back(int(condd));tt=0;
}
if((double(conde)==double((std::ceil(conde))))or(double(conde)==double((std::floor(conde))))){ttake.push_back(int(conde));tt=0;
}
	if(tt==1){
	trynextmult=1;
//std::cout<<" another factor necessary "<<k<<endl;
	}

}

k++;

} //while trynextmult==1

k=k-1;
//std::cout<<"factor needed for multiplication: "<<k<<endl;
int multfactor=k;

///////////////////////////////////////////////////////////////////////////
// now: which tuples of length 3 occur how often

std::vector <std::vector <int > > threetuples;

for(int i=0;i<ttake.size()-2;i++)
{
	int m1= 1;//gcd(ttake[i],ttake[i+1]);
	int min_=ttake[i];
	if(ttake[i+1]<min_){min_=ttake[i+1];}
	//std::cout<<"gcd "<<ttake[i]<<" "<<ttake[i+1]<<" min: "<<min_<<endl;
	for(int k=1;k<=min_;k++){
	if((ttake[i]%k==0)and(ttake[i+1]%k==0)){
		m1=k;
		}
	}

	int m123= 1; //gcd(ttake[i+1],ttake[i+2]);
	int minn=ttake[i+2];
	if(m1<minn){minn=m1;}
	for(int k=1;k<=minn;k++){
	if((m1%k==0)and(int(ttake[i+2])%k==0))
			{m123=k; 
			}
	}



/*
	std::cout<<" ttake[i] "<<ttake[i]<<" "<<ttake[i+1]<<" "<<ttake[i+2]<<endl;
	std::cout<<" ** "<<m1<<" "<<m123<<endl;
	std::cout<<" ttake[i] "<<ttake[i]/m123<<" "<<ttake[i+1]/m123<<" "<<ttake[i+2]/m123<<endl;
*/
	threetuples.push_back(std::vector <int>());
	threetuples[threetuples.size()-1].push_back(ttake[i]/m123);
	threetuples[threetuples.size()-1].push_back(ttake[i+1]/m123);
	threetuples[threetuples.size()-1].push_back(ttake[i+2]/m123);

	threetuples[threetuples.size()-1].push_back(1);

	threetuples[threetuples.size()-1].push_back(int(ttake[i+0]+ttake[i+1]+ttake[i+2]));

//std::cout<<"threetuples || "<<threetuples[threetuples.size()-1][0]<<" "<<threetuples[threetuples.size()-1][1]<<" "<<threetuples[threetuples.size()-1][2]<<" bins: "<<threetuples[threetuples.size()-1][3]<<endl<<endl;

}



////////////////////////////////////////////////////////////////////////

std::vector <std::vector <int> > bin2;
int lb2= std::ceil(double(hist.size())/2);

///////////////////////////////////////////////////////////////////////


std::vector <std::vector <int> > rhythm_all_three;
for(int i=0;i<rhythm_all_string.size();i++)
{
	rhythm_all_three.push_back(std::vector <int>());

	for(int j=0;j<rhythm_all_string[i].size();j++)
	{
	rhythm_all_three[i].push_back(std::stoi(rhythm_all_string[i][j]));
	}
	
}



std::vector <std::vector <double> > rhythm_features;

for(int i=0;i<rhythm_all_three.size();i++)
{

	rhythm_features.push_back(std::vector <double>());
	rhythm_features[i].push_back(i); 
	rhythm_features[i].push_back(0); 

	
}
////////////////////////////////////////////////////////////////////////////


std::vector <std::vector <int> > threetuples_mod;
for(int i=0;i<threetuples.size();i++)
{
threetuples_mod.push_back(std::vector <int> ());

for(int j=0;j<threetuples[i].size();j++){
threetuples_mod[i].push_back(threetuples[i][j]);
}
}

int sum_tuples=threetuples_mod.size();
int sum_tuples_found=0;





for(int i=0;i<threetuples_mod.size();i++)
{
for(int j=0;j<rhythm_all_three.size();j++)
	{
	if((threetuples_mod[i][0]==rhythm_all_three[j][0])and(threetuples_mod[i][1]==rhythm_all_three[j][1])and(threetuples_mod[i][2]==rhythm_all_three[j][2])){
rhythm_features[j][1]=rhythm_features[j][1]+1; //threetuples_mod[i][3]; //adds number of counts this feature is present

	sum_tuples_found=sum_tuples_found+1;//threetuples_mod[i][3];
	}
	}
}




double fraction_found=(double(sum_tuples_found)/double(sum_tuples));

std::vector <double>  rhythmfeatures;


for(int j=0;j<rhythm_features.size();j++)
	{

	rhythm_features[j][1]=(rhythm_features[j][1]/double(sum_tuples));
	rhythmfeatures.push_back(rhythm_features[j][1]); ///double(sum_tuples));
	}


rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(fraction_found);

rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(threetuples.size());

rhythm_features.push_back(std::vector <double> ());
rhythm_features[rhythm_features.size()-1].push_back(0);
rhythm_features[rhythm_features.size()-1].push_back(threetuples_mod.size());


/////////////////////////////////////////////////////////////////////////////
//return rhythm_features;

return rhythmfeatures;
}

