#include <vector>
#include <string>
#include <fstream>
#include <cstring>
#include <Rcpp.h> 

using namespace Rcpp;

using namespace std ;



//' Reads from the mid the length of a bar, and beats per minute
//[[Rcpp::export]]
std::vector <double>  barlength_and_bpm( std::vector <std::vector <std::string> >& mid) {

std::vector <std::vector <double> > blen;

double cltick=0;
double onebar=0;
int firsttemp=0;
int firsttime=0;

std::vector <std::vector < double > > beats;

for(int i=0;i<mid.size();i++)
{
	
for(int j=0;j<mid[i].size();j++)
	{

	//std::cout<<mid[i][j]<<" ";
	if(mid[i][j]=="Set Tempo"){

	//std::cout<<mid[i][0]<<" "<<mid[i][1]<<" "<<mid[i][2]<<" "<<mid[i][1]<<" "<<mid[i][1]<<" "<<mid[i][1]<<" ";;

	//std::cout<<"TEMPO j=0: "<<mid[i][0]<<" 1:"<<mid[i][1]<<" 2: "<<mid[i][2]<<" 3: "<<mid[i][3]<<" 4: "<<mid[i][4]<<" 5: "<<mid[i][5]<<" 6: "<<mid[i][6]<<" 7: "<<mid[i][7]<<" 8: "<<mid[i][8]<<endl;

	firsttemp++;
    	std::string d;
	d=mid[i][7];
	if(std::stod(d)!=0){
   	cltick=(60000000/std::stod(d));}
  	//std::cout <<" bpm: "<< cltick << endl;
	}


} //std::cout<<endl;
}



double lasttime=stod(mid[mid.size()-1][1]);

//cout<<"lasttime: "<<lasttime<<endl;

////////////////////////////////////////////////////////////////////

for(int i=0;i<mid.size();i++)
{
for(int j=0;j<mid[i].size();j++)
	{
	//std::cout<<" 2 loops "<<i<<" "<<j<<endl;
	if((mid[i][j]=="Time Signature")and(firsttime==0)){
//	std::cout<<" if loop mid[i].size() "<<mid[i].size()<<endl;
	firsttime++;

	std::string d1 = mid[i][7];
//	std::cout<<" j=0: "<<mid[i][0]<<" 1:"<<mid[i][1]<<" 2: "<<mid[i][2]<<" 3: "<<mid[i][3]<<" 4: "<<mid[i][4]<<" 5: "<<mid[i][5]<<" 6: "<<mid[i][6]<<" 7: "<<mid[i][7]<<" 8: "<<mid[i][8]<<endl;
	
	std::size_t pos1 = d1.find("/"); 
	//std::cout<<" pos1: "<<pos1<<endl;

  	std::string d2 = d1.substr(pos1+1); 
  	std::string d3 = d2.substr(0, d2.length()-1); 

	double denom=std::stod(d3);
	//std::cout<<" denom: "<<denom<<endl;

	std::size_t pos2 = d1.find("clocks/tick"); 
  	std::string d4 = d1.substr(pos2-3, 2); 
	//std::cout<<" substring d4 (clocks/tick) "<<d4<<endl;


  	std::string n1 = d1.substr(0,pos1); 
	beats.push_back(std::vector<double>());
	
	beats[beats.size()-1].push_back(std::stoi(mid[i][1])); //0
	beats[beats.size()-1].push_back(std::stoi(mid[i][8])); //1: NUMBER OF BEATS
double num=std::stod(n1);

double tlen=(4*num*60/(denom*cltick));
	beats[beats.size()-1].push_back(tlen); //2

	if((beats.size())>1){
	beats[beats.size()-1].push_back(std::stoi(mid[i][1])-beats[beats.size()-2][0]); //3
	}else{
	beats[beats.size()-1].push_back(std::stod(mid[i][1])); //3 
	}	
	beats[beats.size()-1].push_back(denom); //4

	}

	}	

}

///////////////////////////////////////////////////////////////

	for(int i=0;i<beats.size();i++)
	{
	if(beats.size()-1>i){
	beats[i].push_back(beats[i+1][0]-beats[i][0]); //5 : timespan how ong beat goes, take this line to caculate further
	}else{
	beats[beats.size()-1].push_back(lasttime-beats[i][0]);
	}	

	}


int maxb=beats[0][4];
int maxind=0;
	for(int i=0;i<beats.size();i++)
	{

	if(beats[i][5]>maxb){maxind=i;} //timespan 
	}


/////////////////////////////////////////////////////////////////
std::vector <double> blen_bpm;

/*
blen.push_back(std::vector <double>() );
blen[blen.size()-1].push_back(0);
blen[blen.size()-1].push_back(cltick);


blen.push_back(std::vector <double>() );
blen[blen.size()-1].push_back(1);
blen[blen.size()-1].push_back(beats[maxind][1]);

blen.push_back(std::vector <double>() );
blen[blen.size()-1].push_back(2);

double denom=beats[maxind][4];
blen[blen.size()-1].push_back(beats[maxind][2]);
*/


blen_bpm.push_back(beats[maxind][2]);
blen_bpm.push_back(cltick);


//blen_bpm.push_back(1);
//blen_bpm.push_back(1);
return blen_bpm;

}

