
#include <vector>
#include <string>
#include <fstream>
#include <iostream>



#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ; // this important! without it will not work
//' Reads in a monophonic midi file and returns object 'samp' that the other functions can read in.
// [[Rcpp::export]]
std::vector <std::vector <int> > convert_midi(std::vector < std::vector < std::string > >& mididat){

//////////////////////////////////////////////////////////////////////////////////////

   std::vector < std::vector < int > > lengths1 ;

   int nexti=0;
   int i=0;
// last lines have Note Off and End of Track
	//std::cout<<" mididat.size()-2 "<<(mididat.size()-2)<<" nexti: "<<nexti<<endl;
   while(nexti < (mididat.size()-2)){
	i=nexti;
	//std::cout<<" in while loop, mididat[i][2] (should be On for example) "<<mididat[i][2]<<endl;
     if(mididat[i][2]=="Note On")
     { //std::cout<<" Note On found "<<endl;
       lengths1.push_back(std::vector < int >());
       int k0=0;
       if((mididat[i+1][2]=="Note Off")and(mididat[i][5]==mididat[i+1][5]))
       {
         lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i+1][1])-std::stoi(mididat[i][1]));
         k0=1;
         nexti++;
       }else{ 
         if((mididat[i+2][2]=="Note Off")and(mididat[i][5]==mididat[i+2][5]))
         {
           int one=std::stoi(mididat[i+2][1]);
           int two=std::stoi(mididat[i][1]);
           int diff=one-two;
           
           lengths1[lengths1.size()-1].push_back(one-two);
           k0=1;
           
           nexti=nexti+2;
           
         }
         else if((mididat[i+3][2]=="Note Off")and(i<(mididat.size()-3))and(mididat[i][5]==mididat[i+3][5]))
         {
           lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i+3][1])-std::stoi(mididat[i][1]));
           k0=1;
           
           nexti=nexti+3;
         }
         else if((mididat[i+4][2]=="Note Off")and(i<(mididat.size()-4))and(mididat[i][5]==mididat[i+4][5]))
         {
           k0=1;
           lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i+4][1])-std::stoi(mididat[i][1]));
           
           nexti=nexti+4;
         }
         else if((mididat[i+5][2]=="Note Off")and(i<(mididat.size()-5))and(mididat[i][5]==mididat[i+5][5]))
         {
           k0=1;
           lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i+5][1])-std::stoi(mididat[i][1]));
           //i=i+4;
           nexti=nexti+5;
         }
         else{int z=5;
           while((mididat[i+z][2]!="Note Off")and((i+z)<mididat.size())){z++;
           }
           if(mididat[i][5]==mididat[i+z][5]){
             lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i+z][1])-std::stoi(mididat[i][1]));
             k0=1;
             std::cout<<"OFF found after step: "<<z<<endl;
             nexti=nexti+1;
           }}
         
         
       }
       
       if(k0==0){
         std::cout<<"NOTELENGTH NOT FOUND "<<i<<endl;
         lengths1[lengths1.size()-1].push_back(0);
         nexti=nexti+1;
         k0=1;
       }
       
       lengths1[lengths1.size()-1].push_back((std::stoi(mididat[i][5])-69)); // note
       
       lengths1[lengths1.size()-1].push_back(std::stoi(mididat[i][1])); //starttime
       
       
     }else{nexti++;} //if "On"
     
   } // end while loop
   
//   std::cout<<" length of lengths1: "<<lengths1.size()<<endl;
   
  return(lengths1);
}
