#include <algorithm>
#include <vector>
//#include <string>
//#include <fstream>
#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ;

//' Calculates the fraction of time the melody spends on each of the 12 notes in the scale, where 0 is the tonic note. (i.e. the length is normalized by the length of the melody)
// [[Rcpp::export]]
std::vector <double> length_notes_tonic(std::vector< std::vector < int > >& samp, int tonic) {

//std::vector <std::vector <double> > length_notes_tonic(std::vector< std::vector < int > >& samp, int tonic) {


std::vector < std::vector <int> > samp_keyright;
for(int i=0;i<samp.size();i++)
	{
	samp_keyright.push_back(std::vector <int>());

	for(int j=0;j<samp[i].size();j++)
		{
		samp_keyright[samp_keyright.size()-1].push_back(samp[i][j]);
		}
	}



//for(int i=0;i<tonic.size();i++){
int deltat=samp[0][1]-tonic;
samp_keyright[0][1]=deltat;
//}




std::vector<int> different_notes; //1st column: note, second:
std::vector< std::vector <int > > hist_notes;

different_notes.push_back(samp[0][1]);

for(int i=0;i<samp_keyright.size();i++)
{
int k=0;
for(int j=0;j<different_notes.size();j++)
	{
	if(samp_keyright[i][1]==different_notes[j]){
	k=1;
	}
	}
if(k==0){different_notes.push_back(samp_keyright[i][1]);}
}


 std::sort(different_notes.begin(), different_notes.end());           

for(int j=0;j<different_notes.size();j++){
hist_notes.push_back(std::vector <int>());

hist_notes[j].push_back(different_notes[j]); // how many notes
hist_notes[j].push_back(0); // how many notes
hist_notes[j].push_back(0); // cumulative length of these notes
}


for(int i=1;i<samp.size();i++)
{
for(int j=0;j<different_notes.size();j++)
	{
	
	if(samp[i][1]==different_notes[j]){
	hist_notes[j][1]++;
	hist_notes[j][2]=hist_notes[j][2]+samp[i][0];
	}
	}
}


for(int i=0;i<hist_notes.size();i++)
{
hist_notes[i][0]=((hist_notes[i][0]+24)% 12);
}
sort(hist_notes.begin(),hist_notes.end());


std::vector <int> time_intervals;
std::vector < std::vector <int> > time_intervals_abs;



for(int i=0;i<samp_keyright.size()-1;i++)
{

int delta=(samp[i+1][1]-samp[i][1]);
time_intervals.push_back(delta);
time_intervals_abs.push_back(std::vector<int>());

time_intervals_abs[time_intervals_abs.size()-1].push_back((samp_keyright[i][1]+36)%12);//notes now wth respect to each tonic
time_intervals_abs[time_intervals_abs.size()-1].push_back(samp_keyright[i][0]); // notlength

}


std::vector < std::vector <int> > int_abs_ordered;

for(int i=0;i<time_intervals.size();i++){
int_abs_ordered.push_back(std::vector<int>());
int_abs_ordered[int_abs_ordered.size()-1].push_back(time_intervals_abs[i][0]);
int_abs_ordered[int_abs_ordered.size()-1].push_back(time_intervals_abs[i][1]);
}




sort(int_abs_ordered.begin(),int_abs_ordered.end());


std::vector< std::vector <int> > length_on_interval;
length_on_interval.push_back(std::vector <int>());
length_on_interval[length_on_interval.size()-1].push_back(int_abs_ordered[1][0]);
length_on_interval[length_on_interval.size()-1].push_back(int_abs_ordered[1][1]);
for(int i=1;i<time_intervals.size();i++){
	if(int_abs_ordered[i][0]==int_abs_ordered[i-1][0])
	{
	length_on_interval[length_on_interval.size()-1][1]=length_on_interval[length_on_interval.size()-1][1]+int_abs_ordered[i][1];
	}
	else{
	length_on_interval.push_back(std::vector<int>());
	length_on_interval[length_on_interval.size()-1].push_back(int_abs_ordered[i][0]);
	length_on_interval[length_on_interval.size()-1].push_back(int_abs_ordered[i][1]);
	}


}


int sum_length_interval=0;

for(int i=0;i<length_on_interval.size();i++)
{
sum_length_interval=sum_length_interval+length_on_interval[i][1];
}


std::vector <std::vector <double > > rel_length;


std::vector <double > rellength;

for(int i=0;i<12;i++){
rellength.push_back(0);
rel_length.push_back(std::vector <double>());
rel_length[rel_length.size()-1].push_back(i);
rel_length[rel_length.size()-1].push_back(0);
rel_length[rel_length.size()-1].push_back(0);
}

int jj=0;
for(int i=0;i<12;i++){
if(jj<length_on_interval.size()){
if((length_on_interval[jj][0]==i)and(sum_length_interval!=0)){
	rellength[i]=(double(length_on_interval[jj][1])/double(sum_length_interval));
	rel_length[i][1]=(double(length_on_interval[jj][1])/double(sum_length_interval));


	rel_length[i][2]=length_on_interval[jj][1];
	jj++;	
	}
}
}


//return rel_length;
return rellength;

}

