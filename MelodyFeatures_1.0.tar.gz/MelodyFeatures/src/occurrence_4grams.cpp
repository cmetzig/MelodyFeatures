#include <vector>

#include <fstream>
#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ;


//' Counts the number of occurrence of 3-grams, normalized by the total number of intervals in the midi file (=number of notes -3).
//' samp: object of type samp (read from readmidicsv.R)
//[[Rcpp::export]]

std::vector <double>  occurrence_4grams(std::vector< std::vector < int > >& samp) { // statstics how often every interval appears

//std::vector <std::vector <double> > occurrence_4grams(std::vector< std::vector < int > >& samp) { // statstics how often every interval appears

// calculate interval std::vector

	std::vector <int> intervals1;
	for(int i=0;i<samp.size()-1;i++)
	{
	intervals1.push_back(samp[i+1][1]-samp[i][1]);
	}

// calculate quadruple interval matrix -12 to +12
std::vector <std::vector <int> > intervals_quadruple;


for(int i=0; i< 25; i++)
{
for(int j=0; j< 25; j++)
{
for(int k=0; k< 25; k++)
{
	intervals_quadruple.push_back(std::vector <int> ());
	intervals_quadruple[intervals_quadruple.size()-1].push_back(i-12);
	intervals_quadruple[intervals_quadruple.size()-1].push_back(j-12);
	intervals_quadruple[intervals_quadruple.size()-1].push_back(k-12);
	intervals_quadruple[intervals_quadruple.size()-1].push_back(0);
}
}
}


// see where intervals fit


for(int i=0;i<intervals1.size()-2;i++)
	{
	for(int j=0;j<intervals_quadruple.size();j++)
	{
	if((intervals1[i]==intervals_quadruple[j][0])and(intervals1[i+1]==intervals_quadruple[j][1])and(intervals1[i+2]==intervals_quadruple[j][2]))
		{
			intervals_quadruple[j][3]++;
		}
	}
	}


// normalize by number of quadruple intervals in the song



std::vector <double>  occ_quadrupleint;

std::vector <std::vector <double> > occ_quadruple_int;
for(int i=0; i<intervals_quadruple.size();i++)
	{

double newn=(1000000*intervals_quadruple[i][0]+1000*intervals_quadruple[i][1]+intervals_quadruple[i][2]);
int is;
occ_quadruple_int.push_back(std::vector <double> ());
occ_quadruple_int[occ_quadruple_int.size()-1].push_back(newn);

if(intervals1.size()<2){is=1;}else{is=(intervals1.size()-1);}
occ_quadruple_int[occ_quadruple_int.size()-1].push_back(double(intervals_quadruple[i][3])/double(is));
occ_quadrupleint.push_back(double(intervals_quadruple[i][3])/double(is));
	}

//return occ_quadruple_int;
return occ_quadrupleint;

}

