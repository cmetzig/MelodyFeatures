
#include <algorithm>
#include <vector>
#include <string>
#include <fstream>
#include <Rcpp.h> 
using namespace Rcpp;

using namespace std ;

//' counts the occurrence of the 12 notes in the scale (0 is the tonic note). The counts are normalized by the number of notes in the midi file
// [[Rcpp::export]]
std::vector <double>  occurrence_notes_tonic(std::vector < std::vector < int > > & samp,  int tonic) {

//std::vector < std::vector <double> > occurrence_notes_tonic(std::vector < std::vector < int > > & samp,  int tonic) {
std::vector < std::string > scale_mode;



std::vector <int> different_notes; //1st column: note, second:
std::vector < std::vector <int> > hist_notes;

different_notes.push_back(samp[0][1]);

for(int i=0;i<samp.size();i++)
{
int k=0;
for(int j=0;j<different_notes.size();j++)
	{
	if(samp[i][1]==different_notes[j]){
	k=1;
	}
	}
if(k==0){different_notes.push_back(samp[i][1]);}
}

for(int j=0;j<different_notes.size();j++){
different_notes[j]=((different_notes[j]-tonic+24)%12);
}

std::sort(different_notes.begin(), different_notes.end());           

for(int j=different_notes.size()-1;j>0;j--){
if(different_notes[j]==different_notes[j-1])
	{
	different_notes.erase(different_notes.begin()+j);
	}
}

for(int j=0;j<different_notes.size();j++){

hist_notes.push_back(std::vector <int>());
hist_notes[j].push_back(different_notes[j]); // how many notes
hist_notes[j].push_back(0); // how many notes
hist_notes[j].push_back(0); // cumulative length of these notes
}


for(int i=0;i<samp.size();i++)
{
for(int j=0;j<different_notes.size();j++)
	{
	
	if(((samp[i][1]-tonic+24)%12)==different_notes[j]){
	hist_notes[j][1]++;
	hist_notes[j][2]=hist_notes[j][2]+samp[i][0];
	}
	}
}

sort(hist_notes.begin(),hist_notes.end());


int sum_hist=0;

for(int j=0;j<hist_notes.size();j++)
{
sum_hist=sum_hist+hist_notes[j][1];
}


std::vector < std::vector < double > > rel_occurrence;

std::vector < double >  reloccurrence;

for(int i=0;i<12;i++){
reloccurrence.push_back(0);
rel_occurrence.push_back(std::vector <double>());
rel_occurrence[rel_occurrence.size()-1].push_back(double(i));
rel_occurrence[rel_occurrence.size()-1].push_back(0);

}


int jj=0;
for(int i=0;i<12;i++){

if(jj<hist_notes.size()){
if(hist_notes[jj][0]==i){
	reloccurrence[i]=(double(hist_notes[jj][1])/double(sum_hist));
	rel_occurrence[i][1]=(double(hist_notes[jj][1])/double(sum_hist));
	rel_occurrence[i][2]=(hist_notes[jj][1]);
	jj++;	
	}}

}

//return rel_occurrence;
return reloccurrence;
}

