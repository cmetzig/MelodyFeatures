decide_tonic <- function(lengths0, lengths1, tonic_choice=question){
  
  dict_notes <- dict_and_equiv()
  tonic_lastnote_nb=lengths1[[length(lengths1)]][2]
  t_ind=which(as.data.frame(dict_notes)[2,]==tonic_lastnote_nb)
	print(t_ind)
if(length(t_ind)>1){t_ind=t_ind[1]}
  tonic_lastnote=dict_notes[[t_ind]][1]
  
  tonic_key=(strsplit(lengths0[[3]][8], " ")[[1]][1])
#  if(strsplit(lengths0[[3]][8], " ")[1]=="major"){
#    tonic_key=(strsplit(lengths0[[3]][8], " ")[[1]][1])}

  tonic_key_ind=which(as.data.frame(dict_notes)[1,]==tonic_key)

  tonic_key_nb=as.numeric(dict_notes[[tonic_key_ind]][2])
  
  tonic_return=tonic_key_nb
if(tonic_choice=="question"){
  
  tonic_answer <- readline(prompt = "Enter tonic choice: from key(1), from last note (2), any other note (e.g. A)")
  if(tonic_answer=="1"){tonic_return=tonic_key_nb}
  if(tonic_answer=="2"){tonic_return=tonic_lastnote_nb}
  if((tonic_answer!="1")&&(tonic_answer!="2")){
    tonic_answer_ind=which(as.data.frame(dict_notes)[1,]==as.character(tonic_answer))
    tonic_answer_nb=as.numeric(dict_notes[[tonic_answer_ind]][2])
    print(paste("number is ",tonic_answer_nb,sep=""))
    tonic_return=tonic_answer_nb
    }
  }
  
  if(tonic_choice=="lastnote"){tonic_return=tonic_lastnote_nb}
  if(tonic_choice=="key"){tonic_return=tonic_key_nb}
  
 treturn <- c(list(c(tonic_return, 0, tonic_key_nb,1)),list(c(tonic_return, 0, tonic_key_nb,1)))
  
  return(tonic_return)
}
