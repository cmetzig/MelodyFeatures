occurrence_intervals <- function(lengths1)
{
  intervals_all <- sapply(1:(length(lengths1)-1), function(x){return(lengths1[[x+1]][2]-lengths1[[x]][2])}) 
  
ints_poss <- seq(-24,24, by=1)
hist_ints= rep(0, length(ints_poss))
hi <- sapply(1:length(ints_poss), function(x) {return(length(which(intervals_all==ints_poss[x])))})
hi_norm=hi/length(intervals_all)
  
return(hi_norm)
}