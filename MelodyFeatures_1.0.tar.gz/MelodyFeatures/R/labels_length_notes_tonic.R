labels_length_notes_tonic <- function(){ 
lab = c("note_len0",
"note_len1",
"note_len2",
"note_len3",
"note_len4",
"note_len5",
"note_len6",
"note_len7",
"note_len8",
"note_len9",
"note_len10",
"note_len11")
return(lab)
}
