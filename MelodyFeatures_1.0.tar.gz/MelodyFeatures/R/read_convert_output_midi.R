
require(tuneR)

read_convert_output_midi <- function(filen1){
  
  print(filen1)
  m_all <- readMidi(filen1)
  #write.table(m_all, file=paste(outdir, "/midi.csv", sep=""),row.names=TRUE, col.names=TRUE,  quote = FALSE, sep=" ")
  ############# conversion into readable by convert_midi
  m_all_c <- lapply(1:nrow(m_all), function(x){
    linech <- sapply(1:length(m_all[x,]), function(y){
      m_all[x,][is.na(m_all[x,])==TRUE] <- "NA"
      return( as.character(m_all[x,y]))})
    linech1 <- c(as.character(x),linech)
    return(linech1)})
  m_all_converted <- c(list(colnames(m_all)), m_all_c)
  
  ############
  return(m_all_converted)
}
