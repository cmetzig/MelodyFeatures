labels_occurrence_notes_tonic <- function(){ 
lab = c("note_occ0",
"note_occ1",
"note_occ2",
"note_occ3",
"note_occ4",
"note_occ5",
"note_occ6",
"note_occ7",
"note_occ8",
"note_occ9",
"note_occ10",
"note_occ11")
return(lab)
}
